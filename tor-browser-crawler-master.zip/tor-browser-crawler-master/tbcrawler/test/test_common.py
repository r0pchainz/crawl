import unittest


class CommonTest(unittest.TestCase):
    def test_common(self):
        pass


if __name__ == "__main__":
    unittest.main()
