"""Auto-generated file, do not edit by hand. 31 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_31 = [NumberFormat(pattern='([1-578]\\d)(\\d{4})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['1[035]|2[0346]|3[03568]|4[0356]|5[0358]|7|8[4578]']), NumberFormat(pattern='([1-5]\\d{2})(\\d{2})(\\d{2})(\\d{2})', format='\\1 \\2 \\3 \\4', leading_digits_pattern=['1[16-8]|2[259]|3[124]|4[17-9]|5[124679]'])]
