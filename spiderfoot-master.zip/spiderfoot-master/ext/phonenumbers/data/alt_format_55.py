"""Auto-generated file, do not edit by hand. 55 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_55 = [NumberFormat(pattern='(\\d{2})(\\d{8})', format='\\1 \\2', leading_digits_pattern=['[1-9][1-9]'])]
