<?php
namespace VDB\Spider\Exception;

/**
 * @author Matthijs van den Bos <matthijs@vandenbos.org>
 * @copyright 2013 Matthijs van den Bos
 *
 * TODO: refactor to MaxQueueSizeExceededExeption
 */
class QueueException extends \Exception
{
}
