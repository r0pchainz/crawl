# Contributing #

1. Fork [repo](https://github.com/pyvim/metacrawler).
2. Add/update/remove any functional.
3. Send [pull request](https://github.com/pyvim/metacrawler/pulls).

## Maintainers ##

- Vitalii Maslov <<me@pyvim>> (author);
