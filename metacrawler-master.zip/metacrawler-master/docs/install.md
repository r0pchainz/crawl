title:      Installation
prev_title: Summary
prev_url:   index.html
next_title: Library Reference
next_url:   reference.html

# Installing MetaCrawler #

The easiest way to install MetaCrawler is simply to type the
following command from the command line:

    `pip install metacrawler`

You're ready to [use](reference) MetaCralwer.
