next_url:   install.html
next_title: Installation
prev_title: Table of Contents
prev_url:   siteindex.html

# MetaCrawler #

This is a library for simply creating web-crawlers.

See the [installation instructions](install) to get started.

## Support ##

You may ask for help and discuss various other issues on the [bug tracker][].

[bug tracker]: http://github.com/pyvim/metacrawler/issues
