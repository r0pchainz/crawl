# coding=utf-8

from elements import CustomHandler

if __name__ == '__main__':
    handler = CustomHandler()
    handler.start()
    handler.output(compact=False)
