===========
MetaCrawler
===========
*A lightweight Python crawling framework.*

Installation
------------
`pip install metacrawler`

Source
------
`Github
<https://github.com/pyvim/metacrawler>`_
