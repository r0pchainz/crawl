# Python_Search

Search Engine/web crawler python script.
Built during Udacity CS101 course.

Creates an index dictionary by crawling web upto a given depth. Ranks results using the Page Rank algorithm.

Ranking done using graphs
