<!--
Thanks for using pyspider!

如果你需要使用中文提问，请将问题提交到 https://segmentfault.com/t/pyspider
-->

* pyspider version:
* Operating system:
* Start up command:

### Expected behavior

<!-- What do you think should happen? -->

### Actual behavior

<!-- What actually happens? -->

### How to reproduce

<!-- 

The best chance of getting help is providing enough information that can be reproduce the issue you have.

If it's related to API or extraction behavior, please paste the script of your project.
If it's related to scheduling of whole project, please paste the screenshot of queue status on the top in dashboard.

-->
